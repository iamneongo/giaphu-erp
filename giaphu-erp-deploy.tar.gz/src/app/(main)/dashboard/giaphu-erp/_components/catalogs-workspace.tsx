"use client";

import * as React from "react";

import { Archive, BookOpen, Plus, RotateCcw } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ERP_PERMISSIONS } from "@/lib/clerk/erp-rbac-shared";
import { buildNextCatalogCode } from "@/lib/giaphu-erp/catalog-codes";
import { isValidPhoneNumber } from "@/lib/giaphu-erp/phone";
import type { CatalogItem } from "@/lib/giaphu-erp/types";

import { useCanAccessErpPermission } from "../../_components/effective-permissions-provider";
import { useGiaPhuErp } from "../_hooks/use-giaphu-erp";
import { usePaginatedErpRows } from "../_hooks/use-paginated-erp-rows";
import type { CatalogKind } from "../_lib/catalog-config";
import { getCatalogSectionByKind } from "../_lib/catalog-config";
import { catalogOptions, uniqueOptions } from "../_lib/form-options";
import { ActionDialog, type FormFieldDefinition } from "./action-dialog";
import { DataTable, type DataTableColumn } from "./data-table";
import { ExcelImportDialog, type ExcelImportField } from "./excel-import-dialog";
import { ModuleHeader } from "./module-header";
import { SectionBlock } from "./section-block";
import { TableRowActions } from "./table-row-actions";

export function CatalogsWorkspace({ kind }: { kind: CatalogKind }) {
  const { activeProjectCode, data, isSwitchingProject, runAction } = useGiaPhuErp();
  const section = getCatalogSectionByKind(kind);
  const rows = data.catalogs[kind];
  const [archiveTab, setArchiveTab] = React.useState<"active" | "archived">("active");
  const isArchivedTab = archiveTab === "archived";
  const supplierOptions = React.useMemo(() => catalogOptions(data.catalogs.nhaCungCap), [data.catalogs.nhaCungCap]);
  const activeRowsCount = React.useMemo(() => rows.filter((row) => !row.archived).length, [rows]);
  const archivedRowsCount = React.useMemo(() => rows.filter((row) => row.archived).length, [rows]);
  const initialTabRows = React.useMemo(
    () => rows.filter((row) => row.archived === isArchivedTab),
    [isArchivedTab, rows],
  );
  const catalogFixedFilters = React.useMemo(
    () => ({ kind, archived: isArchivedTab ? "true" : "false" }),
    [isArchivedTab, kind],
  );
  const paginatedCatalogs = usePaginatedErpRows<CatalogItem>({
    dataset: "catalogs",
    projectCode: kind === "hangMuc" ? activeProjectCode : "",
    initialRows: initialTabRows,
    fixedFilters: catalogFixedFilters,
  });
  const requiresPhoneContact = kind === "thauPhu" || kind === "nhaCungCap";
  const contactField: FormFieldDefinition = {
    name: "contact",
    label: "Liên hệ",
    required: requiresPhoneContact,
    type: "tel",
    inputMode: "tel",
    placeholder: "Ví dụ: 0901234567",
    validate: (value) => {
      if (!requiresPhoneContact || !value.trim()) return undefined;
      return isValidPhoneNumber(value) ? undefined : "Liên hệ phải là số điện thoại hợp lệ.";
    },
  };
  const canManage = useCanAccessErpPermission(ERP_PERMISSIONS.catalogsManage);
  const fields: FormFieldDefinition[] = [
    { name: "kind", label: "Loại danh mục", type: "hidden", value: section.kind },
    ...(kind === "hangMuc"
      ? [{ name: "projectCode", label: "Công trình", type: "hidden" as const, value: activeProjectCode }]
      : []),
    {
      name: "code",
      label: section.codeLabel,
      value: buildNextCatalogCode(
        kind,
        rows.map((row) => row.code),
      ),
      required: true,
    },
    { name: "name", label: section.nameLabel, required: true },
  ];

  if (section.showUnit) {
    fields.push({ name: "unit", label: "Đơn vị", required: true });
  }

  if (section.showSupplier) {
    fields.push({
      name: "supplier",
      label: "NCC",
      type: "select",
      options: supplierOptions,
      placeholder: "Chọn nhà cung cấp",
      required: true,
      helperText: supplierOptions.length ? "Lấy từ Danh mục > Nhà cung cấp." : "Thêm NCC ở Danh mục > Nhà cung cấp.",
    });
  }

  if (section.showContact) {
    fields.push(contactField);
  }

  fields.push({ name: "note", label: section.noteLabel, type: "textarea" });

  const importFields: ExcelImportField[] = [
    { key: "kind", label: "Loại", hidden: true, defaultValue: section.kind },
    ...(kind === "hangMuc"
      ? [{ key: "projectCode", label: "Công trình", hidden: true, defaultValue: activeProjectCode }]
      : []),
    { key: "code", label: section.codeLabel, aliases: ["Mã", "Ma", "Code"] },
    { key: "name", label: section.nameLabel, aliases: ["Tên", "Ten", "Name"], required: true },
  ];

  if (section.showUnit) {
    importFields.push({ key: "unit", label: "Đơn vị", aliases: ["Don vi", "ĐV"], required: true });
  }

  if (section.showSupplier) {
    importFields.push({
      key: "supplier",
      label: "NCC",
      aliases: ["Nhà CC", "Nhà cung cấp", "Nha cung cap"],
      required: true,
    });
  }

  if (section.showContact) {
    importFields.push({
      key: "contact",
      label: "Liên hệ",
      aliases: ["Lien he", "SĐT", "Phone"],
      required: true,
      validate: (value) => {
        const contact = String(value ?? "").trim();
        return !contact || isValidPhoneNumber(contact) ? undefined : "Liên hệ phải là số điện thoại hợp lệ.";
      },
    });
  }

  importFields.push({ key: "note", label: section.noteLabel, aliases: ["Ghi chú", "Ghi chu"] });

  const columns: DataTableColumn<(typeof rows)[number]>[] = [
    { key: "code", label: "Mã", accessor: (row) => row.code, render: (row) => row.code || "-" },
    { key: "name", label: "Tên", accessor: (row) => row.name, render: (row) => row.name || "-" },
  ];

  if (section.showUnit) {
    columns.push({ key: "unit", label: "Đơn vị", accessor: (row) => row.unit, render: (row) => row.unit || "-" });
  }

  if (section.showSupplier) {
    columns.push({
      key: "supplier",
      label: "NCC",
      accessor: (row) => row.supplier,
      render: (row) => row.supplier || "-",
    });
  }

  if (section.showContact) {
    columns.push({
      key: "contact",
      label: "Liên hệ",
      accessor: (row) => row.contact,
      render: (row) => row.contact || "-",
    });
  }

  columns.push({ key: "note", label: "Ghi chú", accessor: (row) => row.note, render: (row) => row.note || "-" });

  columns.push({
    key: "archived",
    label: "Trạng thái",
    accessor: (row) => (row.archived ? "Đã lưu trữ" : "Đang dùng"),
    render: (row) => (
      <Badge variant={row.archived ? "secondary" : "outline"}>{row.archived ? "Đã lưu trữ" : "Đang dùng"}</Badge>
    ),
  });

  if (canManage) {
    columns.push({
      key: "actions",
      label: "Thao tác",
      hideable: false,
      searchable: false,
      sortable: false,
      render: (row) => (
        <div className="flex justify-end">
          <TableRowActions
            edit={{
              title: `Sửa ${section.navigationTitle.toLowerCase()}`,
              action: "manageCatalog",
              onAction: runAction,
              fields: [
                { name: "originalId", label: "ID", type: "hidden", value: row.id },
                { name: "archived", label: "Lưu trữ", type: "hidden", value: row.archived ? "true" : "false" },
                { name: "kind", label: "Loại danh mục", type: "hidden", value: section.kind },
                ...(kind === "hangMuc"
                  ? [
                      {
                        name: "projectCode",
                        label: "Công trình",
                        type: "hidden" as const,
                        value: row.projectCode || activeProjectCode,
                      },
                    ]
                  : []),
                { name: "code", label: section.codeLabel, required: true, value: row.code },
                { name: "name", label: section.nameLabel, required: true, value: row.name },
                ...(section.showUnit ? [{ name: "unit", label: "Đơn vị", required: true, value: row.unit }] : []),
                ...(section.showSupplier
                  ? [
                      {
                        name: "supplier",
                        label: "NCC",
                        type: "select" as const,
                        options: supplierOptions,
                        placeholder: "Chọn nhà cung cấp",
                        required: true,
                        value: row.supplier,
                        helperText: supplierOptions.length
                          ? "Lấy từ Danh mục > Nhà cung cấp."
                          : "Thêm NCC ở Danh mục > Nhà cung cấp.",
                      },
                    ]
                  : []),
                ...(section.showContact ? [{ ...contactField, value: row.contact }] : []),
                { name: "note", label: section.noteLabel, type: "textarea" as const, value: row.note },
              ],
            }}
            actions={[
              {
                label: row.archived ? "Khôi phục" : "Lưu trữ",
                icon: row.archived ? RotateCcw : Archive,
                destructive: false,
                onSelect: () => {
                  const message = row.archived
                    ? `Khôi phục "${row.name}"? Mục này sẽ hiển thị lại trong danh mục chọn.`
                    : `Lưu trữ "${row.name}"? Mục này sẽ ẩn khỏi danh mục chọn nhưng dữ liệu cũ vẫn được giữ lại.`;
                  if (window.confirm(message)) {
                    return runAction(row.archived ? "restoreCatalog" : "deleteCatalog", {
                      id: row.id,
                    });
                  }
                },
              },
            ]}
          />
        </div>
      ),
    });
  }

  return (
    <div className="flex flex-col gap-4 md:gap-6">
      <ModuleHeader
        title={section.title}
        description={section.description}
        icon={BookOpen}
        actions={
          canManage ? (
            <div className="flex flex-wrap items-center gap-2">
              <ExcelImportDialog
                title={`Import ${section.navigationTitle.toLowerCase()} từ Excel`}
                action="manageCatalog"
                onAction={runAction}
                onImported={paginatedCatalogs.refresh}
                fields={importFields}
              />
              <ActionDialog
                title={`Thêm ${section.navigationTitle.toLowerCase()}`}
                button={section.navigationTitle}
                icon={Plus}
                action="manageCatalog"
                onAction={runAction}
                fields={fields}
              />
            </div>
          ) : undefined
        }
      />

      <SectionBlock
        title={section.navigationTitle}
        meta={<Badge variant="outline">{paginatedCatalogs.total.toLocaleString("vi-VN")} mục</Badge>}
      >
        <Tabs value={archiveTab} onValueChange={(value) => setArchiveTab(value as "active" | "archived")}>
          <TabsList variant="line" className="mb-3 w-fit">
            <TabsTrigger value="active">Hiện tại ({activeRowsCount.toLocaleString("vi-VN")})</TabsTrigger>
            <TabsTrigger value="archived">Lưu trữ ({archivedRowsCount.toLocaleString("vi-VN")})</TabsTrigger>
          </TabsList>
        </Tabs>
        <DataTable
          loading={isSwitchingProject}
          columns={columns}
          rows={paginatedCatalogs.rows}
          getRowId={(row) => row.id}
          serverSide={paginatedCatalogs.serverSide}
          detailType="catalogs"
          selectable
          bulkDeleteAction={
            canManage && !isArchivedTab
              ? {
                  confirmMessage: (selectedRows) =>
                    `Lưu trữ ${selectedRows.length.toLocaleString("vi-VN")} mục đã chọn? Dữ liệu cũ vẫn được giữ lại.`,
                  onDelete: async (selectedRows) => {
                    for (const row of selectedRows.filter((item) => !item.archived)) {
                      await runAction("deleteCatalog", { id: row.id });
                    }
                    paginatedCatalogs.refresh();
                  },
                }
              : undefined
          }
          exportFileName={`danh-muc-${section.kind}`}
          searchPlaceholder={`Tìm ${section.navigationTitle.toLowerCase()}...`}
          filters={[
            ...(section.showUnit
              ? [{ key: "unit", label: "Đơn vị", options: uniqueOptions(rows.map((row) => row.unit)) }]
              : []),
            ...(section.showSupplier
              ? [{ key: "supplier", label: "NCC", options: uniqueOptions(rows.map((row) => row.supplier)) }]
              : []),
            ...(section.showContact
              ? [{ key: "contact", label: "Liên hệ", options: uniqueOptions(rows.map((row) => row.contact)) }]
              : []),
          ]}
        />
      </SectionBlock>
    </div>
  );
}
