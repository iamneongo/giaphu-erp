import { redirect } from "next/navigation";

export default function Page() {
  redirect("/dashboard/giaphu-erp/catalogs/hang-muc");
}
