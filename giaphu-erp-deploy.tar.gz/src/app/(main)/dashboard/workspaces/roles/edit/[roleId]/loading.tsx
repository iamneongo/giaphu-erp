import { RoleEditorSkeleton } from "../../../../_components/loading-skeletons";

export default function Loading() {
  return <RoleEditorSkeleton />;
}
